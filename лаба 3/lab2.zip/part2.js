// Объявление пустого хэша для хранения информации о транспортных средствах
let transportHash = {};

// Функция добавления информации о транспортном средстве
function AddValue(key, value) {
    transportHash[key] = value;
}

// Функция удаления информации о транспортном средстве
function DeleteValue(key) {
    if (transportHash.hasOwnProperty(key)) {
        delete transportHash[key];
    }
}

// Функция получения информации о транспортном средстве
function GetValueInfo(key) {
    if (transportHash.hasOwnProperty(key)) {
        return transportHash[key];
    } else {
        return "нет информации";
    }
}

// Функция вывода списка всех транспортных средств
function ListValues() {
    let result = "";
    for (let key in transportHash) {
        result += `${key}: ${transportHash[key]}\n`;
    }
    return result;
}
